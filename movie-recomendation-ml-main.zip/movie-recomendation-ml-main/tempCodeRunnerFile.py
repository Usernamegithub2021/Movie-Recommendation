input_data = pd.DataFrame({
#     'country': [country],
#     'rating': [rating],
#     'duration': [duration],
#     'type': [mors]
# })

# # Vectorize the input movie details
# input_vectorized = vectorizer.transform(input_data['country'] +
#                                         ' ' + input_data['rating'] + ' ' + input_data['duration'] + ' ' + input_data['type'])

# # Make prediction on the input movie
# prediction = model.predict(input_vectorized)
